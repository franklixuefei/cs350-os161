#include <stdio.h>

int main(int argc, char **argv) {
	printf("Hi, this is a custom test\n");
}
