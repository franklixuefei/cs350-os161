/* Automatically generated; do not edit */
#ifndef _OPT_A3_H_
#define _OPT_A3_H_
#define OPT_A3 1
#endif /* _OPT_A3_H_ */
