/*
 * getpid by Frank Li
 */
#include "opt-A2.h"

#if OPT-A2
#include <syscall.h>
int
sys_waitpid(pid_t pid, int *status, int options, pid_t *retval)
{
    
    int err = 0;
    return err;
}
#endif

